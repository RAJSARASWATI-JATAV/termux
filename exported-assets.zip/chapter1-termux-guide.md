# Chapter 1: Termux की शुरुआत - Complete Beginner's Guide
## आपका पहला कदम Android Linux की दुनिया में

### What is Termux? (Termux क्या है?)

Termux एक **powerful Android terminal emulator** है जो आपके smartphone पर **complete Linux environment** provide करती है। यह **बिना root** के काम करती है और आपको access देती है:

- **Linux command-line interface** का full power
- **Package management system** (pkg/apt)
- **Programming languages** (Python, Node.js, C/C++, etc.)
- **Development tools** (Git, editors, compilers)
- **Network tools** (curl, wget, ssh)

---

## Phase 1: Proper Installation (सही तरीके से Install करें)

### Why NOT Google Play Store?

❌ **Google Play Store की problems:**
- Outdated version (कई महीने पुराना)
- Limited permissions
- Missing features
- Compatibility issues
- No regular updates

✅ **F-Droid के benefits:**
- Latest stable version
- Full permissions
- Complete feature set
- Regular security updates
- Official developer support

### Step-by-Step Installation

#### Step 1: Download F-Droid
```
Website: https://f-droid.org
File: F-Droid.apk (around 10MB)
Time: 2-3 minutes
```

#### Step 2: Enable Unknown Sources
```
Settings → Security → Install unknown apps → Allow from this source
(यह setting browser के लिए enable करें)
```

#### Step 3: Install F-Droid
```
Downloaded APK को tap करें → Install → Open
```

#### Step 4: Find Termux in F-Droid
```
F-Droid app open करें → Search "Termux" → Install
Package name: com.termux
Size: ~250MB
```

#### Step 5: Optional - Install Termux Add-ons
```
Termux:API - Android features access
Termux:Styling - Themes and fonts
Termux:Widget - Home screen shortcuts
```

---

## Phase 2: First Launch Setup

### Step 1: Initial Update (बहुत जरूरी!)
```bash
# पहला command - हमेशा यह करें
pkg update && pkg upgrade

# यह command करता है:
# - Package lists को update करता है
# - Security patches install करता है
# - Latest versions available करता है
```

### Step 2: Storage Permission Setup
```bash
# Storage access के लिए
termux-setup-storage

# Permission dialog में "Allow" करें
# यह create करेगा ~/storage/ directory
```

**Storage Directories की जानकारी:**
- `~/storage/shared` - Main internal storage
- `~/storage/downloads` - Download folder
- `~/storage/dcim` - Camera photos
- `~/storage/pictures` - Pictures folder
- `~/storage/music` - Music files
- `~/storage/movies` - Video files

### Step 3: Enable Extra Keys
```bash
# Method 1: Quick toggle
# Volume Up + Q press करें

# Method 2: Permanent enable
mkdir -p ~/.termux
echo 'extra-keys = [["ESC","TAB","CTRL","ALT","-","HOME","UP","END"],["CTRL+A","CTRL+C","CTRL+V","LEFT","DOWN","RIGHT","PGUP","PGDN"]]' > ~/.termux/termux.properties
termux-reload-settings
```

---

## Phase 3: Essential Packages Installation

### Basic Development Tools
```bash
# Text editors
pkg install nano      # Beginner-friendly editor
pkg install vim       # Advanced editor

# Version control
pkg install git       # Code versioning

# Network tools
pkg install curl wget # File downloading

# Archive tools
pkg install zip unzip tar
```

### Programming Languages
```bash
# Python (most popular)
pkg install python
pip install --upgrade pip

# Node.js (web development)
pkg install nodejs npm

# C/C++ compiler
pkg install clang

# Java (if needed)
pkg install openjdk-17
```

### System Utilities
```bash
# Process monitoring
pkg install htop

# File management
pkg install tree      # Directory structure view
pkg install file      # File type identification

# System information
pkg install neofetch   # Beautiful system info
```

---

## Phase 4: Understanding Directory Structure

### Termux File System Layout
```
/data/data/com.termux/files/
├── home/              # Your home directory ($HOME)
│   ├── storage/       # Android storage links
│   └── .termux/       # Configuration files
└── usr/               # System files ($PREFIX)
    ├── bin/           # Executable programs
    ├── etc/           # Configuration files
    ├── lib/           # Libraries
    ├── share/         # Shared data
    └── var/           # Variable data
```

### Important Environment Variables
```bash
# Check these with:
echo $HOME          # /data/data/com.termux/files/home
echo $PREFIX        # /data/data/com.termux/files/usr
echo $PATH          # Shows executable paths

# Useful commands:
pwd                 # Current directory
whoami             # Current user
uname -a           # System information
```

---

## Phase 5: Basic Navigation Commands

### File and Directory Operations
```bash
# List files and directories
ls                  # Simple list
ls -l              # Detailed list
ls -la             # Include hidden files
ls -lh             # Human-readable sizes

# Navigate directories
cd ~               # Go to home
cd /               # Go to root
cd ..              # Go up one level
cd storage/        # Go to storage

# Current location
pwd                # Print working directory

# Create directories
mkdir folder_name
mkdir -p path/to/nested/folders

# Create files
touch filename.txt
echo "content" > filename.txt

# View file content
cat filename.txt   # Show entire file
head filename.txt  # First 10 lines
tail filename.txt  # Last 10 lines
less filename.txt  # Scrollable view

# Copy and move
cp source destination
cp -r folder1 folder2    # Copy directory
mv oldname newname       # Rename/move

# Delete files and folders
rm filename.txt
rm -rf folder_name       # Delete directory and contents
```

### Essential File Editing
```bash
# Using nano (beginner-friendly)
nano filename.txt

# Nano shortcuts:
# Ctrl+X = Exit
# Ctrl+O = Save
# Ctrl+W = Search
# Ctrl+K = Cut line
# Ctrl+U = Paste line
```

---

## Phase 6: Package Management

### Understanding pkg vs apt
```bash
# pkg is recommended (wrapper around apt)
pkg install package_name    # Auto-updates repos
pkg upgrade                 # Update all packages
pkg search keyword          # Search packages
pkg list-installed          # Show installed
pkg uninstall package_name  # Remove package

# apt (direct package manager)
apt update                  # Update package lists
apt install package_name    # Install package
apt remove package_name     # Remove package
```

### Repository Management
```bash
# Enable additional repositories
pkg install x11-repo        # GUI applications
pkg install root-repo       # Root tools
pkg install science-repo    # Scientific tools
pkg install game-repo       # Games

# Check available repos
pkg list-all | grep repo
```

---

## Phase 7: Keyboard Shortcuts & Extra Keys

### Volume Key Shortcuts
```
Volume Down + Key:
├── L → Clear screen (Ctrl+L)
├── C → Cancel command (Ctrl+C)
├── D → Exit/Logout (Ctrl+D)
├── K → Cut line (Ctrl+K)
├── A → Beginning of line (Ctrl+A)
└── E → End of line (Ctrl+E)

Volume Up + Key:
├── Q → Toggle extra keys
├── T → Tab key
├── E → Escape key
├── W → Up arrow
├── A → Left arrow
├── S → Down arrow
├── D → Right arrow
├── 1-9 → F1-F9 function keys
└── H → Tilde (~)
```

### Useful Command Shortcuts
```bash
# History navigation
!!                 # Previous command
!keyword          # Last command starting with keyword
history           # Command history

# Tab completion
pkg in<TAB>       # Completes to "pkg install"
cd st<TAB>        # Completes to "cd storage/"

# Process control
Ctrl+C            # Stop current process
Ctrl+Z            # Suspend process
fg               # Resume suspended process
bg               # Send process to background
```

---

## Phase 8: Customization & Themes

### Terminal Styling
```bash
# Install styling package (from F-Droid)
# Termux:Styling app provides:
# - Color schemes
# - Font options
# - Theme variations

# Access styling:
# Long press terminal → More → Style
# Or install Termux:Styling app
```

### Custom prompt
```bash
# Add to ~/.bashrc for permanent changes
echo 'PS1="\[\033[1;32m\]\u@termux\[\033[0m\]:\[\033[1;34m\]\w\[\033[0m\]\$ "' >> ~/.bashrc
source ~/.bashrc
```

### Aliases for convenience
```bash
# Add useful shortcuts
echo 'alias ll="ls -la"' >> ~/.bashrc
echo 'alias la="ls -la"' >> ~/.bashrc
echo 'alias update="pkg update && pkg upgrade"' >> ~/.bashrc
echo 'alias ..="cd .."' >> ~/.bashrc
echo 'alias ...="cd ../.."' >> ~/.bashrc

# Reload configuration
source ~/.bashrc
```

---

## Phase 9: Troubleshooting Common Issues

### Installation Problems
**Problem:** Package installation fails
```bash
# Solution:
pkg update
pkg upgrade
pkg install package_name
```

**Problem:** Storage permission denied
```bash
# Solution:
# Android Settings → Apps → Termux → Permissions → Files and media → Allow
# Then run: termux-setup-storage
```

### Performance Issues
**Problem:** Slow performance
```bash
# Solutions:
pkg autoclean          # Clean package cache
pkg autoremove         # Remove unused packages
rm -rf ~/.cache/*      # Clear user cache
```

**Problem:** App crashes
```bash
# Solutions:
# 1. Clear app data (Settings → Apps → Termux → Storage → Clear Data)
# 2. Reinstall from F-Droid
# 3. Check available storage space
```

### Permission Issues
**Problem:** Can't access files
```bash
# Check permissions:
ls -la filename
chmod +r filename      # Add read permission
chmod +w filename      # Add write permission
chmod +x filename      # Add execute permission
chmod 755 filename     # Common permission set
```

---

## Phase 10: Your First Projects

### Project 1: System Information Script
```bash
# Create a system info script
nano sysinfo.sh

# Add this content:
#!/bin/bash
echo "=== System Information ==="
echo "Device: $(getprop ro.product.model)"
echo "Android: $(getprop ro.build.version.release)"
echo "Architecture: $(uname -m)"
echo "User: $(whoami)"
echo "Home: $HOME"
echo "Storage: $(df -h $HOME)"
echo "Date: $(date)"

# Make executable and run:
chmod +x sysinfo.sh
./sysinfo.sh
```

### Project 2: File Backup Script
```bash
# Create backup script
nano backup.sh

#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="$HOME/backups"
mkdir -p "$BACKUP_DIR"

echo "Creating backup: backup_$DATE.tar.gz"
tar -czf "$BACKUP_DIR/backup_$DATE.tar.gz" -C "$HOME" \
  --exclude=backups \
  --exclude=storage \
  .

echo "Backup completed: $BACKUP_DIR/backup_$DATE.tar.gz"
ls -lh "$BACKUP_DIR/backup_$DATE.tar.gz"
```

### Project 3: Quick Setup Script
```bash
# Create auto-setup script for new Termux installations
nano quick-setup.sh

#!/bin/bash
echo "🚀 Termux Quick Setup Starting..."

# Update packages
echo "📦 Updating packages..."
pkg update -y && pkg upgrade -y

# Install essentials
echo "🔧 Installing essential packages..."
pkg install -y git curl wget nano python nodejs htop

# Setup storage
echo "💾 Setting up storage..."
termux-setup-storage

# Create useful aliases
echo "⚡ Creating aliases..."
cat >> ~/.bashrc << 'EOF'
alias ll='ls -la'
alias la='ls -la' 
alias ..='cd ..'
alias update='pkg update && pkg upgrade'
alias install='pkg install'
EOF

source ~/.bashrc
echo "✅ Setup completed!"
```

---

## Important Tips for Beginners

### DO's ✅
1. **Always update first**: `pkg update && pkg upgrade`
2. **Use F-Droid version**: More stable and updated
3. **Enable extra keys**: Makes typing much easier
4. **Regular backups**: Important files को backup रखें
5. **Learn gradually**: Basic commands से शुरू करें

### DON'Ts ❌  
1. **Don't use Google Play version**: Outdated और limited
2. **Don't skip updates**: Security के लिए important
3. **Don't delete system files**: $PREFIX में files modify न करें
4. **Don't run unknown scripts**: Security risk हो सकती है
5. **Don't expect root features**: Termux is userspace only

### Next Steps
1. Learn basic Linux commands thoroughly
2. Practice file management
3. Start with simple programming
4. Explore package ecosystem  
5. Try building small projects
6. Join Termux community forums

---

## Quick Reference Commands

### Most Used Commands (Daily Use)
```bash
pkg update && pkg upgrade    # Update system
ls -la                      # List files
cd directory_name           # Change directory  
nano filename              # Edit file
cat filename               # View file
cp source dest            # Copy file
rm filename               # Delete file
clear                     # Clear screen
exit                      # Close session
```

### Package Management
```bash
pkg search keyword         # Search packages
pkg install package       # Install package
pkg list-installed        # Show installed
pkg uninstall package     # Remove package
pkg upgrade               # Update all
```

### System Information  
```bash
whoami                    # Current user
pwd                       # Current directory
uname -a                  # System info
df -h                     # Disk usage
free -h                   # Memory usage
```

यह guide आपको Termux की solid foundation देगी। Regular practice करें और धीरे-धीरे advanced features explore करें!