import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Create the data
data = [
    {"Installation_Method": "F-Droid", "Update_Frequency": 9, "Stability": 9, "Feature_Completeness": 10, "Security": 10},
    {"Installation_Method": "Google Play Store", "Update_Frequency": 3, "Stability": 5, "Feature_Completeness": 6, "Security": 7},
    {"Installation_Method": "GitHub Direct APK", "Update_Frequency": 10, "Stability": 8, "Feature_Completeness": 10, "Security": 9}
]

df = pd.DataFrame(data)

# Reshape data for grouped bar chart
df_melted = df.melt(id_vars=['Installation_Method'], 
                    value_vars=['Update_Frequency', 'Stability', 'Feature_Completeness', 'Security'],
                    var_name='Metric', value_name='Score')

# Shorten the metric names to fit 15 character limit
metric_mapping = {
    'Update_Frequency': 'Update Freq',
    'Stability': 'Stability', 
    'Feature_Completeness': 'Features',
    'Security': 'Security'
}
df_melted['Metric'] = df_melted['Metric'].map(metric_mapping)

# Shorten installation method names to fit 15 character limit
method_mapping = {
    'F-Droid': 'F-Droid',
    'Google Play Store': 'Play Store',
    'GitHub Direct APK': 'GitHub APK'
}
df_melted['Installation_Method'] = df_melted['Installation_Method'].map(method_mapping)

# Create grouped bar chart
fig = px.bar(df_melted, 
             x='Installation_Method', 
             y='Score',
             color='Metric',
             barmode='group',
             title='Termux Install Methods Comparison',
             color_discrete_sequence=['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F'])

# Update layout according to requirements
fig.update_layout(
    xaxis_title='Install Method',
    yaxis_title='Score (1-10)',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

fig.update_yaxes(range=[0, 10])

# Save the chart
fig.write_image('termux_comparison.png')